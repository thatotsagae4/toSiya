import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:textformfield_example/widget/button_widget.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static final String title = 'TextFormField';

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: title,
        theme: ThemeData(primaryColor: Colors.red),
        home: MainPage(title: title),
      );
}

class MainPage extends StatefulWidget {
  final String title;

  const MainPage({
    @required this.title,
  });

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final formKey = GlobalKey<FormState>();
  TextEditingController drsnamesurname = TextEditingController();
  final drsemail = TextEditingController();
  final department = TextEditingController();
  final patientname = TextEditingController();
  final typeofdiaonosis = TextEditingController();

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        body: Form(
          key: formKey,
          child: ListView(
            padding: EdgeInsets.all(16),
            children: [
              buildName(),
              const SizedBox(height: 32),
              buildEmail(),
              const SizedBox(height: 32),
              builddepartment(),
              const SizedBox(height: 32),
              builddepatientname(),
              const SizedBox(height: 32),
              buildtypeofdiagnosis(),
              const SizedBox(height: 32),
              buildSubmit(),
            ],
          ),
        ),
      );

  Widget buildName() => TextFormField(
        decoration: InputDecoration(
            labelText: 'Practationers name and surname',
            border: OutlineInputBorder(),
            suffixIcon: IconButton(
              onPressed: () => drsnamesurname.clear(),
              icon: Icon(Icons.close),
            )),
        validator: (value) {
          if (value.length < 2) {
            return 'Enter at least 4 characters';
          } else {
            return null;
          }
        },
        maxLength: 30,
        onSaved: (value) => setState(() => drsnamesurname.text = value),
      );

  Widget buildEmail() => TextFormField(
        decoration: InputDecoration(
            labelText: 'Email',
            border: OutlineInputBorder(),
            suffixIcon: IconButton(
              onPressed: () => drsemail.clear(),
              icon: Icon(Icons.close),
            )),
        validator: (val) =>
            val.isEmpty || !val.contains("@") ? "enter a valid eamil" : null,
        maxLength: 30,
        onSaved: (value) => setState(() => drsemail.text = value),
      );

  Widget builddepartment() => TextFormField(
        decoration: InputDecoration(
            labelText: 'Department',
            border: OutlineInputBorder(),
            suffixIcon: IconButton(
              onPressed: () => department.clear(),
              icon: Icon(Icons.close),
            )),
        validator: (value) {
          if (value.length < 2) {
            return 'Enter at least 4 characters';
          } else {
            return null;
          }
        },
        maxLength: 30,
        onSaved: (value) => setState(() => department.text = value),
      );

  Widget builddepatientname() => TextFormField(
        decoration: InputDecoration(
            labelText: 'Patient Name',
            border: OutlineInputBorder(),
            suffixIcon: IconButton(
              onPressed: () => patientname.clear(),
              icon: Icon(Icons.close),
            )),
        validator: (value) {
          if (value.length < 2) {
            return 'Enter at least 4 characters';
          } else {
            return null;
          }
        },
        maxLength: 30,
        onSaved: (value) => setState(() => patientname.text = value),
      );

  Widget buildtypeofdiagnosis() => TextFormField(
        decoration: InputDecoration(
            labelText: 'Type of diagnosis',
            border: OutlineInputBorder(),
            suffixIcon: IconButton(
              onPressed: () => typeofdiaonosis.clear(),
              icon: Icon(Icons.close),
            )),
        validator: (value) {
          if (value.length < 2) {
            return 'Enter at least 4 characters';
          } else {
            return null;
          }
        },
        maxLength: 100,
        onSaved: (value) => setState(() => typeofdiaonosis.text = value),
      );

  Widget buildSubmit() => Builder(
        builder: (context) => ButtonWidget(
          text: 'Submit',
          onClicked: () {
            final isValid = formKey.currentState.validate();
            // FocusScope.of(context).unfocus();

            if (isValid) {
              formKey.currentState.save();

              final message =
                  'Dr details: $drsnamesurname\nPatientName: $patientname';
              final snackBar = SnackBar(
                content: Text(
                  message,
                  style: TextStyle(fontSize: 20),
                ),
                backgroundColor: Colors.green,
              );
              ScaffoldMessenger.of(context).showSnackBar(snackBar);
            }
          },
        ),
      );
}
